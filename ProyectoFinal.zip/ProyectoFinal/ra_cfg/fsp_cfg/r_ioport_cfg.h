/* generated configuration header file - do not edit */
#ifndef R_IOPORT_CFG_H_
#define R_IOPORT_CFG_H_
#ifdef __cplusplus
extern "C" {
#endif

#define IOPORT_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)

#ifdef __cplusplus
}
#endif
#endif /* R_IOPORT_CFG_H_ */
