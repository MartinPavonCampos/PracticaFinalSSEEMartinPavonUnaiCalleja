/*
 * ADC_pot.h
 *
 *  Created on: 11 ene 2024
 *      Author: Hezitzaile
 */

#ifndef ADC_POT_H_
#define ADC_POT_H_
#include "hal_data.h"


#endif /* ADC_POT_H_ */
